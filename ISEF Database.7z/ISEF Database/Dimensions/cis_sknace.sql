﻿CREATE TABLE [dbo].[cis_sknace]
(
	[Kod] [char](5) NOT NULL PRIMARY KEY,
	[Nazov] nvarchar(50) null,
	[Popis] nvarchar(150) null
)
