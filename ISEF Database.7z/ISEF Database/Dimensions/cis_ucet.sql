﻿CREATE TABLE [dbo].[cis_ucet]
(
	[Kod] char(3) NOT NULL PRIMARY KEY,
	[Nazov] nvarchar(55) not null,
	[Popis] nvarchar(255) not null
)
