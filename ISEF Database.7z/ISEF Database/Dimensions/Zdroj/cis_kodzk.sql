﻿CREATE TABLE [dbo].[cis_kodzk]
(
	[Kod] char(1) NOT NULL PRIMARY KEY,
	[Nazov] nvarchar(50) null,
	[Popis] nvarchar(250) null,
)
