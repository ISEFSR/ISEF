CREATE TABLE [dbo].[cis_pk7](
	[Rok] [int] NOT NULL,
	[Kod] [char](7) NOT NULL,
	[Pk5] [char](5) NOT NULL,
	[Nazov] [nvarchar](150) NOT NULL,
	[Popis] [nvarchar](max) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Rok] ASC,
	[Kod] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
	CONSTRAINT [FK_cis_pk7_pk5] FOREIGN KEY (Rok, Pk5) REFERENCES [dbo].[cis_pk5]([Rok], [Kod])
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
