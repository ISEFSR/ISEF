﻿CREATE TABLE [dbo].[roc_ek](
	[pol] [nvarchar](255) NULL,
	[text1] [nvarchar](255) NULL,
	[text2] [nvarchar](255) NULL,
	[textskr] [nvarchar](255) NULL,
	[znac] [nvarchar](255) NULL,
	[pol_tab8] [nvarchar](255) NULL,
	[pol_oon8] [nvarchar](255) NULL,
	[pol_plzu] [nvarchar](255) NULL
) ON [PRIMARY]
GO

