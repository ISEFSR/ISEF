﻿CREATE TABLE [dbo].roc_pk(
	[prog] [nvarchar](255) NULL,
	[text1] [nvarchar](255) NULL,
	[text2] [nvarchar](255) NULL,
	[textskr] [nvarchar](255) NULL,
	[znac] [nvarchar](255) NULL,
	[program] [nvarchar](255) NULL
) ON [PRIMARY]
GO


