﻿CREATE TABLE [dbo].roc_fk(
	[typ] [nvarchar](255) NULL,
	[znac] [nvarchar](255) NULL,
	[textpar] [nvarchar](255) NULL,
	[text15] [nvarchar](255) NULL,
	[pocet] [float] NULL,
	[textpar14] [nvarchar](255) NULL
) ON [PRIMARY]
GO
