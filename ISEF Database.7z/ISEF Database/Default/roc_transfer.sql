﻿CREATE TABLE [dbo].roc_transfer
(
	[FromStupen] char(1) NOT NULL,
	[ToStupen] char(1) NOT NULL,
	[Polozka] char(6) not null
)
